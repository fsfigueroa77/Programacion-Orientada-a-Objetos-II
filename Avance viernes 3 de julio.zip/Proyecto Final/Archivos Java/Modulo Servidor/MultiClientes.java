import java.net.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class MultiClientes extends Thread {
    private Socket cliente;
    private BufferedReader entrada;
    private PrintWriter salida;
    private String usuarioBD = "root";
    private String contraseniaBD = "MyNewPass1";
    private Connection c = null;
    private Statement s = null;
    private ResultSet rs = null;
    private int selectorCliente;
    private String usuario = null;
    private String contrasenia = null;
    private String usuarioConsulta = null;
    private String contraseniaConsulta = null;
    private String consulta = null;

    public MultiClientes(Socket cliente, int selectorCliente) { // CONSTRUCTOR
        this.cliente = cliente;
        this.selectorCliente = selectorCliente;
    }

    @Override
    public void run() {
        boolean acceso = false;
        try{
            entrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
            salida = new PrintWriter(new BufferedWriter(new OutputStreamWriter(cliente.getOutputStream())), true);

            try{
                c = DriverManager.getConnection("jdbc:mysql://localhost:3306/bancoxd", usuarioBD, contraseniaBD);
            } catch (SQLException e) {
                System.out.println("No se puedo establecer conexion con la base de datos");
                System.exit(-1);
            }

            while (!acceso) {
                try {
                    usuario = entrada.readLine(); // 2 RECEPCION DE LINEA DE CLIENTE
                    System.out.println("Usuario leido: " + usuario + " del tipo " + selectorCliente); // PRUEBAS
                    contrasenia = entrada.readLine(); // 3 RECEPCION DE LINEA DE CONTRASEÑA
                    System.out.println("Contraseña leida: " + contrasenia + " del tipo " + selectorCliente); // PRUEBAS
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                    System.exit(-1);
                }

                try {
                    s = c.createStatement();
                    consulta = consulta(usuario);

                    rs = s.executeQuery(consulta);
                    if(rs.next()) {
                        usuarioConsulta = rs.getString(usuario());
                        contraseniaConsulta = rs.getString(contrasenia());
                        if(usuario.equals(usuarioConsulta) && contrasenia.equals(contraseniaConsulta)) {
                            acceso = true;
                            salida.println("Acceso Concedido");
                        } else {
                            salida.println("Usuario o Contraseña no encontrados");
                        }
                    } else {
                        salida.println("Usuario o Contraseña no encontrados");
                    }
                } catch(SQLException e) {
                    System.out.println("No se pudo hacer la consulta del usuario y contrasenia");
                }
            }

        } catch(IOException e) {
            System.out.println("No se pudo realizar la conexion");
            System.exit(-1);
        }
        
        if(selectorCliente == 1) {
            acceso = false;
            String aux = null;
            
            while(!acceso) {
                try {
                    aux = entrada.readLine();
                } catch(IOException e) {
                    System.out.println("No se pudo leer");
                }

                if(Integer.parseInt(aux) == 2) {
                    String cedula = null;
                    String nombres = null;
                    String apellidos = null;
                    String fechaNac = null;
                    String celular = null;
                    String correo = null;
                    String direccion = null;
                    try {
                        cedula = entrada.readLine();
                        nombres = entrada.readLine();
                        apellidos = entrada.readLine();
                        fechaNac = entrada.readLine();
                        celular = entrada.readLine();
                        correo = entrada.readLine();
                        direccion = entrada.readLine();
                    } catch(IOException e) {
                        System.out.println("No se pudo leer");
                    }
                    try {
                        s = c.createStatement();
                        s.executeUpdate("insert into cliente(cedula, nombres, apellidos, fecha_nac, telefono, email, direccion) values('"+cedula+"', '"+nombres+"', '"+apellidos+"', '"+fechaNac+"', '"+celular+"', '"+correo+"', '"+direccion+"');");
                    } catch(SQLException e) {
                        System.out.println(e.getMessage());
                    }
                }
                if(Integer.parseInt(aux) == 11) {
                    acceso = true;
                }
            }
        }

    }

    public String consulta(String usuario) {
        if(selectorCliente == 1) {
            return "select * from empleado where usuario = '" + usuario + "';";
        } else {
            return "select cliente.cedula, cuenta.clave from cliente join cuenta ON cliente.id = cuenta.id_cliente;";
        }
    }

    public String usuario() {
        if(selectorCliente == 1) {
            return "usuario";
        } else {
            return "cedula";
        }
    }

    public String contrasenia() {
        if(selectorCliente == 1) {
            return "contrasenia";
        } else {
            return "clave";
        }
    }

} // FIN DE LA CLASE

/*

*/