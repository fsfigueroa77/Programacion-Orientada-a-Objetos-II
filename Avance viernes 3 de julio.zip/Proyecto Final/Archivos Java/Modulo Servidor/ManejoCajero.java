public class ManejoCajero {
    
} // FIN DE LA CLASE