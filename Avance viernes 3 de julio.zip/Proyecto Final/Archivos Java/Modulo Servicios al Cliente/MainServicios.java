import java.io.*;
import java.net.*;
import java.util.Scanner;

public class MainServicios {
    public static final String IPSERVIDOR = "localhost"; // CAMBIAR IP
    public static final int PUERTO = 4444;
    public static Scanner teclado = new Scanner(System.in);
    public static void main(String[] args) throws IOException {
        Socket cliente = null;
        BufferedReader entrada = null;
        PrintWriter salida = null;

        try {
            cliente = new Socket(IPSERVIDOR, PUERTO);
            entrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
            salida = new PrintWriter(new OutputStreamWriter(cliente.getOutputStream()), true);
        } catch(IOException e) {
            System.out.println("No se pudo establecer conexion con el servidor");
            System.exit(-1);
        }

        tituloPrincipal();

        String lineaEnviar = null;
        String lineaLlegada = null;

        String lineaSalida = "servicios";

        salida.println(lineaSalida); // 1) ENVIO DE LINEA DE TIPO DE CLIENTE

        boolean acceso = false;
        while(!acceso) {
            System.out.println("Ingrese sus credenciales");

            System.out.print("Usuario: ");
            lineaEnviar = teclado.nextLine();
            salida.println(lineaEnviar); // 2) ENVIO DE LINEA DE USUARIO

            System.out.print("Contraseña: ");
            lineaEnviar = teclado.nextLine();
            salida.println(lineaEnviar); // 3) ENVIO DE LINEA DE CONTRASEÑA

            try {
                lineaLlegada = entrada.readLine(); // A) LECTURA DE LINEA DE ACCESO CONCEDIDO O DENEGADO
            } catch (IOException e) {
                System.out.println("No se pudo leer");
            }

            if(lineaLlegada.equals("Acceso Concedido")) {
                acceso = true;
                System.out.println(lineaLlegada);
            } else {
                System.out.println(lineaLlegada);
            }
        } // FIN DEL CICLO DE VERIFICACION

        acceso = false;
        String aux = null;
        
        while(!acceso) {
            impresionMenu();
            aux = teclado.nextLine();
            salida.println(aux);

            switch(Integer.parseInt(aux)) {
                case 1: // CREAR CUENTA
                    menu1();
                    System.out.print("");
                    break;
                case 2: // CREAR USUARIO
                    menu2();
                    System.out.print("Ingrese numero de cedula: ");
                    salida.println(teclado.nextLine());
                    System.out.print("Ingrese los nombres: ");
                    salida.println(teclado.nextLine());
                    System.out.print("Ingrese los apellidos: ");
                    salida.println(teclado.nextLine());
                    System.out.print("Ingrese fecha de nacimiento(YYYY-MM-DD): ");
                    salida.println(teclado.nextLine());
                    System.out.print("Ingrese numero de celular: ");
                    salida.println(teclado.nextLine());
                    System.out.print("Ingrese correo electronico: ");
                    salida.println(teclado.nextLine());
                    System.out.print("Ingrese direccion: ");
                    salida.println(teclado.nextLine());
                    break;
                case 3: // MODIFICAR CUENTA
                    //menu3();
                    break;
                case 4: // MODIFICAR USUARIO
                    //menu4();
                    break;
                case 5: // BORRAR CUENTA
                    //menu5();
                    break;
                case 6: // BORRAR USUARIO
                    //menu6();
                    break;
                case 7: // CONSULTAR SALDO
                    //menu7();
                    break;
                case 8: // CONSULTAR SALDO PROMEDIO
                    //menu8();
                    break;
                case 9: // REPORTE DE MOVIMIENTOS
                    //menu9();
                    break;
                case 10: // DATOS GENERALES
                    //menu10();
                    break;
                case 11:
                    acceso = true;
                    break;
                default:

            }

        }

    } // FIN DEL MAIN

    public static void tituloPrincipal() {
        System.out.println("=============================================================================");
        System.out.println("                            SERVICIOS AL CLIENTE                             ");
        System.out.println("=============================================================================");
    }

    public static void impresionMenu() {
        System.out.println("=============================================================================");
        System.out.println("                               MENU PRINCIPAL                                ");
        System.out.println("=============================================================================");
        System.out.println("1. Crear cuenta");
        System.out.println("2. Crear usuario");
        System.out.println("3. Modificar cuenta");
        System.out.println("4. Modificar usuario");
        System.out.println("5. Borrar cuenta");
        System.out.println("6. Borrar usuario");
        System.out.println("7. Consultar saldo");
        System.out.println("8. Consultar saldo promedio");
        System.out.println("9. Reporte de movimientos");
        System.out.printf("10. Datos generales");
        System.out.println("11. Salir");
        System.out.print("Elija su opcion: ");
    }

    public static void menu1() {
        System.out.println("=============================================================================");
        System.out.println("                               CREAR CUENTA                                  ");
        System.out.println("=============================================================================");
    }

    public static void menu2() {
        System.out.println("=============================================================================");
        System.out.println("                               CREAR USUARIO                                 ");
        System.out.println("=============================================================================");
    }

} // FIN DE LA CLASE
