import java.io.*;
import java.net.*;
import java.util.Scanner;

public class MainCajero {
    public static final String IPSERVIDOR = "localhost"; // CAMBIAR IP
    public static final int PUERTO = 4444;
    public static Scanner teclado = new Scanner(System.in);
    public static void main(String[] args) throws IOException {
        String aux;
        Socket cliente = null;
        BufferedReader entrada = null;
        PrintWriter salida = null;
        String cuentaUsuario;

        try {
            cliente = new Socket(IPSERVIDOR, PUERTO);
            entrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
            salida = new PrintWriter(new OutputStreamWriter(cliente.getOutputStream()), true);
        } catch(IOException e) {
            System.out.println("No se pudo establecer conexion con el servidor");
            System.exit(-1);
        }

        tituloPrincipal();

        String lineaEnviar = null;
        String lineaLlegada = null;

        String lineaSalida = "cajero";

        salida.println(lineaSalida);

        boolean acceso = false;
        while(!acceso) {
            System.out.println("Ingrese sus credenciales");

            System.out.print("Usuario: ");
            lineaEnviar = teclado.nextLine();
            salida.println(lineaEnviar);

            System.out.print("Contraseña: ");
            lineaEnviar = teclado.nextLine();
            salida.println(lineaEnviar);

            try {
                lineaLlegada = entrada.readLine(); // A LECTURA DE LINEA DE ACCESO CONCEDIDO O DENEGADO
            } catch (IOException e) {
                System.out.println("No se pudo leer");
            }

            if(lineaLlegada.equals("Acceso Concedido")) {
                acceso = true;
                System.out.println(lineaLlegada);
            } else {
                System.out.println(lineaLlegada);
            }
        } // FIN DEL CICLO DE VERIFICACION

        acceso = false;
        while(!acceso) {
            impresionMenu();
            aux = teclado.nextLine();

            switch(Integer.parseInt(aux)) {
                case 1: // CONSULTAR SALDOS
                    menu1();
                    break;
                case 2: // CONSULTAR 5 ULTIMOS MOVIMIENTOS
                    menu2();
                    break;
                case 3: // DEPOSITAR
                    menu3();
                    break;
                case 4: // RETIRAR
                    menu4();
                    break;
                case 5: // TRANSFERIR
                    menu5();
                    break;
                default:

            }

        }

    } // FIN DEL MAIN

    public static boolean validarCredenciales(String lineaEnviar, PrintWriter salida, String lineaLlegada, BufferedReader entrada) {
        System.out.println("Ingrese sus credenciales");

        System.out.print("Usuario: ");
        lineaEnviar = teclado.nextLine();
        salida.println(lineaEnviar);

        System.out.print("Contraseña: ");
        lineaEnviar = teclado.nextLine();
        salida.println(lineaEnviar);

        try{
            lineaLlegada = entrada.readLine();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }

        if(lineaLlegada.equals("Acceso Concedido")) {
            System.out.println(lineaLlegada);
            return true;
        } else {
            System.out.println(lineaLlegada);
            return false;
        }

    }

    public static void tituloPrincipal() {
        System.out.println("=============================================================================");
        System.out.println("                              CAJERO AUTOMATICO                              ");
        System.out.println("=============================================================================");
    }

    public static void impresionMenu() {
        System.out.println("=============================================================================");
        System.out.println("                               MENU PRINCIPAL                                ");
        System.out.println("=============================================================================");
        System.out.println("1. Consultar Saldos");
        System.out.println("2. Consultar los 5 ultimos movimientos");
        System.out.println("3. Depositar");
        System.out.println("4. Retirar");
        System.out.println("5. Transferir");
        System.out.print("Elija su opcion: ");
    }

    public static void menu1() {
        System.out.println("=============================================================================");
        System.out.println("                              CONSULTAR SALDOS                               ");
        System.out.println("=============================================================================");
    }

    public static void menu2() {
        System.out.println("=============================================================================");
        System.out.println("                       CONSULTAR 5 ULTIMOS MOVIMIENTOS                       ");
        System.out.println("=============================================================================");
    }

    public static void menu3() {
        System.out.println("=============================================================================");
        System.out.println("                                  DEPOSITAR                                   ");
        System.out.println("=============================================================================");
    }

    public static void menu4() {
        System.out.println("=============================================================================");
        System.out.println("                                  RETIRAR                                    ");
        System.out.println("=============================================================================");
    }

    public static void menu5() {
        System.out.println("=============================================================================");
        System.out.println("                                 TRANSFERIR                                  ");
        System.out.println("=============================================================================");
    }

} // FIN DE LA CLASE