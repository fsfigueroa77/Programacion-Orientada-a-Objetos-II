import java.sql.*;
import java.io.*;

public class PruebaConexion {
    public static void main(String[] args) {
        Connection c = null;
        Statement s = null;
        ResultSet rs = null;

        try {
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/bancoxd", "root", "MyNewPass1");
        } catch(SQLException e) {
            System.out.println("No se puedo conectar a la base de datos.");
            System.exit(-1);
        }

        System.out.println("Conexion a la BD exitosa");

        try{
            s = c.createStatement();
            rs = s.executeQuery("select * from empleado;");
            while(rs.next()) {
                System.out.println(rs.getString("usuario") + ":" + rs.getString("contrasenia"));
            }
        } catch(SQLException e) {
            System.out.println("hola xdxdd");
        }
        
    }
}